#! /usr/bin/env python3
# -*- coding: utf-8 -*-
# ------------------------------------------------------------------------------
#+ Autor:  	Ran#
#+ Creado: 	2022/02/13 15:34:13.985489
#+ Editado:	2022/02/15 20:59:34.316049
# ------------------------------------------------------------------------------
class CreacionSesionErro(Exception):
    pass

class CambioNaPaxinaErro(Exception):
    pass

class ChaveInvalidaErro(Exception):
    pass
# ------------------------------------------------------------------------------
